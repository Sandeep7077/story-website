$(document).ready(function() {
$('.mdb-select').materialSelect();
});